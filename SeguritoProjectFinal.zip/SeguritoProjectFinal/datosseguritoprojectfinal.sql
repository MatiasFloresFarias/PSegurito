
--USUARIO
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$vhEGzaZMgJclASEdfRO3Be3ynPHsrt.XXKMYsFD3j6aAlBkbp1T.K', 'profesional','ROLE_PROFESIONAL');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$RpwEAhQUjkNwijvtG91Iku57FEWmhPepDxhcLEC.fZTbAyYVkCsWe', 'administrador','ROLE_ADMINISTRADOR');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$vTvacYsuAiEs4o/sgxmyiueSKi3I57p9cEztCMJtmNPDmjZlW2q92', 'cliente','ROLE_CLIENTE');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$ElrGfmIAfIGILpB6SngahupNu2tbtrZn4ihcw609dOaZEeP.fCQCy', 'mlillo','ROLE_PROFESIONAL');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$bqplfy/rXuHeKzX29U.PIeGpwi48yJyGP2V3yXpcoNBWRpDamaZCS', 'mflores','ROLE_PROFESIONAL');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$Dc4bEfo0vvXzC6DpPM1Ncuxso1jlBHtfAa8VzrsajtRADA7NuE.Ye', 'jtolorza','ROLE_PROFESIONAL');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$/jUyRyk6clGwagdmm7QMOuMc7esj0FH/pYin3wvf891Q/V.YpkNr.', 'clloncon','ROLE_PROFESIONAL');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$P1XxIboELkfCBpos.2W.EOaTUe54CPSbY/tq13dmDWpewtpsRObaO', 'abarroso','ROLE_PROFESIONAL');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$ND3Xk53aPAmArYeq15xtNekIZLvV9yeHrmKz0rKYNNxPv7h6TegDi', 'transportesSA','ROLE_CLIENTE');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$3ozn4qhF2y/bw9NzmaAhp.ye1wtD/FrbsvJcrSNZXBWChLiQbH5kq', 'minerialaplata','ROLE_CLIENTE');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$FnJKJSLgfJ9U/toL1yedVePdgulCY1dRiiR4YYJR2qFTi9UMril/.', 'bodegasplastic','ROLE_CLIENTE');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$esUBxsBJPeYSxhK67vCUn.P5evup6S9B1MTd9ij48W9VZvYrZ/Wbe', 'oyrltda','ROLE_CLIENTE');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$PDcM31sgBkummMKy0P6Tx.dK4iRQ2qT.hhJl0kFX4bMcdAEu1Fk46', 'constructoracentral','ROLE_CLIENTE');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$9HALNCWZxc1fXBEpdLcgP..p.an7NSZ1nb3iFnm7haRDuyXMUyzhm', 'envasadosgonzalez','ROLE_CLIENTE');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$ILIgC1d5EE8xPHEHe3q97O9nyE14EloVLQiMGNdBeGPgnXz/RYm8a', 'baxter','ROLE_CLIENTE');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$JT6WWZL9akiL5GoXfiQ8BevT2CZW2NXpIArDwXNo.1KQfLrWsU/Bu', 'generalmotors','ROLE_CLIENTE');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$L29n5nvcLXjNQSjoehaleeERnk6Dp2i87N.I76piO0Q5JRse1ZQ1q', 'grupoarmour','ROLE_CLIENTE');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$5Pbig0ZHEkZYIX6pGcJPyeEX/RkwLIgtTKiJIW9S3xBHtU.4L5qf2', 'quintinoexpress','ROLE_CLIENTE');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$PuoFpM05Qg7DMORGLQLIXuGilnagCJ1O4MSsptN5ehCKsfvueGXt.', 'josemendoza','ROLE_PROFESIONAL');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$0wCXwuEioDf2iFvPCZYfHeoF/jWcsxO01fruJ5kPVcKXyn2JBCX/C', 'lorenanunez','ROLE_PROFESIONAL');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$AI4i7DNosFMm4qG.LAaGU.NoxmNIAmIceMtJJJVCY1izIydha4wke', 'cesararaneda','ROLE_PROFESIONAL');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$vrkKtmWAR64isP4dvBQcTeJg9UngsI1X6I4U4u.Sa2FMN2e/OqKUS', 'rodrigovasquez','ROLE_PROFESIONAL');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$y6t3WrHY087m2V1fYQ7pfevJj1o7Bvw3ZYAdyfSoV2vuf6go49lqu', 'aliciamartinez','ROLE_PROFESIONAL');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$PO72svagFBpxvWbI2uMWbeojxFK.tQ3fMHkXzuQ3eYOLloG.vkFJa', 'catalinarojas','ROLE_PROFESIONAL');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$/GoA5NG7WUKfjcE80iojremvglqJU0YyxEk.1NdfaJkUCS4f3ldgO', 'danielcarrasco','ROLE_PROFESIONAL');
INSERT INTO usuario(password,nickname, rol)
values ('$2a$10$d.C1j7ObguTYejU/Z5JYx.jszP.Vn5dRrmiDqnTIc1gt65/DiiFqK', 'jorgecastillo','ROLE_ADMINISTRADOR');

--CLIENTE
INSERT INTO cliente (nombreempresa,rutempresa,fecharegistro, usuario_nickname, usuario_id_usuario)
values ('Transportes S.A','77888999-9',TO_DATE('20/03/2020','dd/mm/yyyy'), 'transportesSA', 9);

INSERT INTO cliente (nombreempresa,rutempresa,fecharegistro, usuario_nickname, usuario_id_usuario)
values ('Mineria La Plata','78999000-0',TO_DATE('15/01/2020','dd/mm/yyyy'), 'minerialaplata', 10);

INSERT INTO cliente (nombreempresa,rutempresa,fecharegistro, usuario_nickname, usuario_id_usuario)
values ('Bodegas Plastic','88000333-9',TO_DATE('10/05/2019','dd/mm/yyyy'), 'bodegasplastic',11);

INSERT INTO cliente (nombreempresa,rutempresa,fecharegistro, usuario_nickname, usuario_id_usuario)
values ('O y R LTDA.','70654389-8',TO_DATE('24/08/2019','dd/mm/yyyy'), 'oyrltda',12);

INSERT INTO cliente (nombreempresa,rutempresa,fecharegistro, usuario_nickname, usuario_id_usuario)
values ('Constructora Central','76604493-1',TO_DATE('30/09/2019','dd/mm/yyyy'), 'constructoracentral', 13);

INSERT INTO cliente (nombreempresa,rutempresa,fecharegistro, usuario_nickname, usuario_id_usuario)
values ('Envasados Gonzalez','75600500-2',TO_DATE('03/02/2019','dd/mm/yyyy'), 'envasadosgonzalez', 14);

INSERT INTO cliente (nombreempresa,rutempresa,fecharegistro, usuario_nickname, usuario_id_usuario)
values ('Baxter','77564321-9',TO_DATE('02/04/2020','dd/mm/yyyy'), 'baxter', 15);

INSERT INTO cliente (nombreempresa,rutempresa,fecharegistro, usuario_nickname, usuario_id_usuario)
values ('General Motors','79560489-4',TO_DATE('07/05/2020','dd/mm/yyyy'), 'generalmotors', 16);

INSERT INTO cliente (nombreempresa,rutempresa,fecharegistro, usuario_nickname, usuario_id_usuario)
values ('Grupo Armour','78005338-1',TO_DATE('19/10/2019','dd/mm/yyyy'), 'grupoarmour', 17);

INSERT INTO cliente (nombreempresa,rutempresa,fecharegistro, usuario_nickname, usuario_id_usuario)
values ('Quintino Express','76534765-2',TO_DATE('05/12/2019','dd/mm/yyyy'), 'quintinoexpress', 18);


--PROFESIONAL
INSERT INTO profesional (nombre,apellido,correo,telefono,cargo, usuario_nickname, usuario_id_usuario)
values ('Jose','Mendoza','josemendoza@segurito.cl','977512400','Prevencionista de riesgo en terreno', 'josemendoza', 19);

INSERT INTO profesional (nombre,apellido,correo,telefono,cargo, usuario_nickname, usuario_id_usuario)
values ('Lorena','Nunez','lorenanunez@segurito.cl','988877699','Coordinadora de calidad de vida laboral', 'lorenanunez', 20);

INSERT INTO profesional (nombre,apellido,correo,telefono,cargo, usuario_nickname, usuario_id_usuario)
values ('Cesar','Araneda','cesararaneda@segurito.cl','999800555','Jefe dpto. prevencion de riesgos laborales', 'cesararaneda', 21);

INSERT INTO profesional (nombre,apellido,correo,telefono,cargo, usuario_nickname, usuario_id_usuario)
values ('Rodrigo','Vasquez','rodrigovasquez@segurito.cl','900033378','Prevencionista de riesgo en terreno', 'rodrigovasquez', 22);

INSERT INTO profesional (nombre,apellido,correo,telefono,cargo, usuario_nickname, usuario_id_usuario)
values ('Alicia','Martinez','aliciamartinez@segurito.cl','977744455','Asesora en Prevencion de Riesgos', 'aliciamartinez', 23);

INSERT INTO profesional (nombre,apellido,correo,telefono,cargo, usuario_nickname, usuario_id_usuario)
values ('Catalina','Rojas','catalinarojas@segurito.cl','966644433','Asesora en Prevencion de Riesgos', 'catalinarojas', 24);

INSERT INTO profesional (nombre,apellido,correo,telefono,cargo, usuario_nickname, usuario_id_usuario)
values ('Daniel','Carrasco','danielcarrasco@segurito.cl','988900043','Prevencionista de riesgo en terreno', 'danielcarrasco', 25);

--ACTIVIDADES MEJORA
INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Accidentes en superficies de trabajo',TO_DATE('01/08/2020','dd/mm/yyyy'),TO_DATE('02/08/2020','dd/mm/yyyy'),'Finalizado','Se reparan partes rotas del piso','1','1');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos en operaciones de maquinas',TO_DATE('20/08/2020','dd/mm/yyyy'),TO_DATE('20/08/2020','dd/mm/yyyy'),'Pendiente','Pintar maquinas segun el codigo de colores','1','2');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos en operaciones de maquinas',TO_DATE('05/01/2020','dd/mm/yyyy'),TO_DATE('01/02/2020','dd/mm/yyyy'),'Finalizado','Se�alizaciones de seguridad','5','3');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos en salidas de emergencia',TO_DATE('10/01/2020','dd/mm/yyyy'),TO_DATE('10/02/2020','dd/mm/yyyy'),'Finalizado','Se�alizar salidas emergencia','2','10');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos en instalaciones electricas',TO_DATE('15/01/2020','dd/mm/yyyy'),TO_DATE('15/02/2020','dd/mm/yyyy'),'Finalizado','Reparar instlaciones electricas','6','8');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos en salidas de emergencia',TO_DATE('25/01/2020','dd/mm/yyyy'),TO_DATE('25/01/2020','dd/mm/yyyy'),'Finalizado','Reparar instalaciones electricas','7','10');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos en salidas de emergencia',TO_DATE('30/01/2020','dd/mm/yyyy'),TO_DATE('01/03/2020','dd/mm/yyyy'),'Finalizado','Se�alizar salidas de emergencia','5','9');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos en salidas de emergencia',TO_DATE('15/01/2020','dd/mm/yyyy'),TO_DATE('15/02/2020','dd/mm/yyyy'),'Finalizado','Se�alizar salidas de emergencia','2','7');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Accidentes en superficies de trabajo',TO_DATE('25/01/2020','dd/mm/yyyy'),TO_DATE('25/02/2020','dd/mm/yyyy'),'Finalizado','Se reparan partes rotas del piso','6','4');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Accidentes en superficies de trabajo',TO_DATE('14/01/2020','dd/mm/yyyy'),TO_DATE('14/02/2020','dd/mm/yyyy'),'Finalizado','Se reparan partes rotas del piso','3','6');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Accidentes en superficies de trabajo',TO_DATE('12/02/2020','dd/mm/yyyy'),TO_DATE('15/03/2020','dd/mm/yyyy'),'Finalizado','Se reparan partes rotas del piso','7','9');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Accidentes de derrame de productos toxicos',TO_DATE('18/02/2020','dd/mm/yyyy'),TO_DATE('18/03/2020','dd/mm/yyyy'),'Finalizado','Organizacion de productos por grado de toxicidad','6','5');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Accidentes de derrame de productos toxicos',TO_DATE('25/02/2020','dd/mm/yyyy'),TO_DATE('25/03/2020','dd/mm/yyyy'),'Finalizado','Organizacion de productos por grado de toxicidad','1','8');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Accidentes en superficies de trabajo',TO_DATE('28/02/2020','dd/mm/yyyy'),TO_DATE('30/03/2020','dd/mm/yyyy'),'Finalizado','Se se�alizan sectores acceso','5','4');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Accidentes en superficies de trabajo',TO_DATE('17/02/2020','dd/mm/yyyy'),TO_DATE('17/03/2020','dd/mm/yyyy'),'Finalizado','Se se�alizan sectores acceso','4','6');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Accidentes en superficies de trabajo',TO_DATE('05/03/2020','dd/mm/yyyy'),TO_DATE('05/04/2020','dd/mm/yyyy'),'Finalizado','Se se�alizan sectores acceso','3','1');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Accidentes en superficies de trabajo',TO_DATE('10/03/2020','dd/mm/yyyy'),TO_DATE('10/04/2020','dd/mm/yyyy'),'Finalizado','Se se�alizan sectores acceso','5','10');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Se�alizar accesos de personal',TO_DATE('13/03/2020','dd/mm/yyyy'),TO_DATE('13/04/2020','dd/mm/yyyy'),'Finalizado','Se se�alizan sectores de acceso para cada personal','4','9');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Se�alizar accesos de personal',TO_DATE('15/03/2020','dd/mm/yyyy'),TO_DATE('15/04/2020','dd/mm/yyyy'),'Finalizado','Se se�alizan sectores de acceso para cada personal','2','2');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Se�alizar accesos de personal',TO_DATE('14/03/2020','dd/mm/yyyy'),TO_DATE('14/04/2020','dd/mm/yyyy'),'Finalizado','Se se�alizan sectores de acceso para cada personal','5','7');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Accidentes en superficies de trabajo',TO_DATE('02/03/2020','dd/mm/yyyy'),TO_DATE('02/04/2020','dd/mm/yyyy'),'Finalizado','Se se�alizan sectores acceso','5','2');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Accidentes en superficies de trabajo',TO_DATE('26/03/2020','dd/mm/yyyy'),TO_DATE('26/03/2020','dd/mm/yyyy'),'Finalizado','Se se�alizan sectores acceso','7','8');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Accidentes en superficies de trabajo',TO_DATE('27/03/2020','dd/mm/yyyy'),TO_DATE('27/04/2020','dd/mm/yyyy'),'Finalizado','Se se�alizan sectores acceso','3','6');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos en salidas de emergencia',TO_DATE('04/04/2020','dd/mm/yyyy'),TO_DATE('04/05/2020','dd/mm/yyyy'),'Finalizado','Se�alizar salidas de emergencia','6','1');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos en salidas de emergencia',TO_DATE('06/04/2020','dd/mm/yyyy'),TO_DATE('06/05/2020','dd/mm/yyyy'),'Finalizado','Se�alizar salidas de emergencia','5','3');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos de caidas cargas pesadas',TO_DATE('07/04/2020','dd/mm/yyyy'),TO_DATE('07/05/2020','dd/mm/yyyy'),'Finalizado','Descarga en sectores habilitados','3','1');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos de caidas cargas pesadas',TO_DATE('15/04/2020','dd/mm/yyyy'),TO_DATE('15/05/2020','dd/mm/yyyy'),'Finalizado','Descarga en sectores habilitados','7','10');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos de caidas cargas pesadas',TO_DATE('25/04/2020','dd/mm/yyyy'),TO_DATE('25/05/2020','dd/mm/yyyy'),'Finalizado','Descarga en sectores habilitados','5','9');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos de caidas cargas pesadas',TO_DATE('06/05/2020','dd/mm/yyyy'),TO_DATE('06/06/2020','dd/mm/yyyy'),'Finalizado','Descarga en sectores habilitados','2','8');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos de caidas cargas pesadas',TO_DATE('15/05/2020','dd/mm/yyyy'),TO_DATE('15/06/2020','dd/mm/yyyy'),'Finalizado','Descarga en sectores habilitados','1','2');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos de caidas cargas pesadas',TO_DATE('25/05/2020','dd/mm/yyyy'),TO_DATE('25/06/2020','dd/mm/yyyy'),'Finalizado','Descarga en sectores habilitados','4','4');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Implementos de seguridad',TO_DATE('20/05/2020','dd/mm/yyyy'),TO_DATE('20/06/2020','dd/mm/yyyy'),'Finalizado','Entrega de implementos de seguridad a trabajadores','2','9');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Implementos de seguridad',TO_DATE('21/05/2020','dd/mm/yyyy'),TO_DATE('21/06/2020','dd/mm/yyyy'),'Finalizado','Entrega de implementos de seguridad a trabajadores','3','8');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Implementos de seguridad',TO_DATE('11/05/2020','dd/mm/yyyy'),TO_DATE('11/06/2020','dd/mm/yyyy'),'Finalizado','Entrega de implementos de seguridad a trabajadores','4','7');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Implementos de seguridad',TO_DATE('13/05/2020','dd/mm/yyyy'),TO_DATE('13/06/2020','dd/mm/yyyy'),'Finalizado','Entrega de implementos de seguridad a trabajadores','1','1');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Implementos de seguridad',TO_DATE('14/05/2020','dd/mm/yyyy'),TO_DATE('14/06/2020','dd/mm/yyyy'),'Finalizado','Entrega de implementos de seguridad a trabajadores','5','5');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Implementos de seguridad',TO_DATE('01/06/2020','dd/mm/yyyy'),TO_DATE('01/07/2020','dd/mm/yyyy'),'Finalizado','Entrega de implementos de seguridad a trabajadores','6','2');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Implementos de seguridad',TO_DATE('03/06/2020','dd/mm/yyyy'),TO_DATE('03/07/2020','dd/mm/yyyy'),'Finalizado','Entrega de implementos de seguridad a trabajadores','7','3');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Implementos de seguridad',TO_DATE('05/06/2020','dd/mm/yyyy'),TO_DATE('05/07/2020','dd/mm/yyyy'),'Finalizado','Entrega de implementos de seguridad a trabajadores','5','6');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Implementos de seguridad',TO_DATE('07/06/2020','dd/mm/yyyy'),TO_DATE('07/07/2020','dd/mm/yyyy'),'Finalizado','Entrega de implementos de seguridad a trabajadores','1','4');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Implementos de seguridad',TO_DATE('10/06/2020','dd/mm/yyyy'),TO_DATE('10/07/2020','dd/mm/yyyy'),'Finalizado','Entrega de implementos de seguridad a trabajadores','3','10');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos de caidas cargas pesadas',TO_DATE('15/06/2020','dd/mm/yyyy'),TO_DATE('15/07/2020','dd/mm/yyyy'),'Finalizado','Descarga en sectores habilitados','5','6');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos de caidas cargas pesadas',TO_DATE('17/06/2020','dd/mm/yyyy'),TO_DATE('17/07/2020','dd/mm/yyyy'),'Finalizado','Descarga en sectores habilitados','1','8');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos de caidas cargas pesadas',TO_DATE('25/06/2020','dd/mm/yyyy'),TO_DATE('25/06/2020','dd/mm/yyyy'),'Finalizado','Descarga en sectores habilitados','2','9');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos de caidas cargas pesadas',TO_DATE('27/06/2020','dd/mm/yyyy'),TO_DATE('27/07/2020','dd/mm/yyyy'),'Finalizado','Descarga en sectores habilitados','6','10');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos en salidas de emergencia',TO_DATE('05/07/2020','dd/mm/yyyy'),TO_DATE('05/08/2020','dd/mm/yyyy'),'Finalizado','Se�alizar salidas de emergencia','2','1');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos en salidas de emergencia',TO_DATE('08/07/2020','dd/mm/yyyy'),TO_DATE('08/08/2020','dd/mm/yyyy'),'Pendiente','Se�alizar salidas de emergencia','3','2');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos en salidas de emergencia',TO_DATE('14/07/2020','dd/mm/yyyy'),TO_DATE('14/08/2020','dd/mm/yyyy'),'Pendiente','Se�alizar salidas de emergencia','6','4');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos en salidas de emergencia',TO_DATE('20/07/2020','dd/mm/yyyy'),TO_DATE('20/08/2020','dd/mm/yyyy'),'Pendiente','Se�alizar salidas de emergencia','4','5');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos en salidas de emergencia',TO_DATE('25/07/2020','dd/mm/yyyy'),TO_DATE('25/08/2020','dd/mm/yyyy'),'Pendiente','Se�alizar salidas de emergencia','4','6');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Riesgos en salidas de emergencia',TO_DATE('25/07/2020','dd/mm/yyyy'),TO_DATE('25/08/2020','dd/mm/yyyy'),'Pendiente','Se�alizar salidas de emergencia','6','8');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Escaleras con pasamanos en mal estado',TO_DATE('26/07/2020','dd/mm/yyyy'),TO_DATE('26/08/2020','dd/mm/yyyy'),'Pendiente','Implementar pasamanos nuevos','3','1');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Escaleras con pasamanos en mal estado',TO_DATE('01/08/2020','dd/mm/yyyy'),TO_DATE('01/09/2020','dd/mm/yyyy'),'Pendiente','Implementar pasamanos nuevos','7','3');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Escaleras con pasamanos en mal estado',TO_DATE('05/08/2020','dd/mm/yyyy'),TO_DATE('05/09/2020','dd/mm/yyyy'),'Pendiente','Implementar pasamanos nuevos','5','4');

INSERT INTO actividadmejora (nombre,fechainicio,fechatermino,estado,detalle,profesional_id_profesional,cliente_id_cliente)
values ('Escaleras con pasamanos en mal estado',TO_DATE('07/08/2020','dd/mm/yyyy'),TO_DATE('07/09/2020','dd/mm/yyyy'),'Pendiente','Implementar pasamanos nuevos','6','6');

--REPORTE ACCIDENTE
INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion, profesional_id_profesional, cliente_id_cliente)
values (TO_DATE('02/08/2020','dd/mm/yyyy'),'Santa Marta 0344','Descarga de camion','Trabajador se dobla tobillo por suelo roto','1', '1');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/08/2020','dd/mm/yyyy'),'Departamental 769','Amago de incendio','Derrame de productos inflamables','1', '2');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/08/2020','dd/mm/yyyy'),'La Aduana 1040','Caida desde escalera','Pierna quebrada','2', '3');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/08/2020','dd/mm/yyyy'),'La Aduana 1040','Atropello','Accidente de trayecto','2', '3');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/08/2020','dd/mm/yyyy'),'La Aduana 1040','Electrocutamiento','Mala gestion y uso de las herramientas de seguridad','2', '3');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/08/2020','dd/mm/yyyy'),'Grecia 7325','Accidente de trayecto','esguince de tobillo','3', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/08/2020','dd/mm/yyyy'),'Mapocho 145','Inhalacion vapor toxico','Derrame de producto toxico','3', '5');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/08/2020','dd/mm/yyyy'),'Macul 200','Lesion traumatica','Objeto pesado cae desde altura','4', '6');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/08/2020','dd/mm/yyyy'),'Providencia 780','Cortes y laceraciones','Corte con equipo e implemento afilado','4', '7');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/08/2020','dd/mm/yyyy'),'San Pablo 5778','Accidente de Trayecto','Ca�da en trayecto','5', '8');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/08/2020','dd/mm/yyyy'),'Santiago 765','Lesiones por el uso de maquinaria y equipos','Fractura de huesos','5', '8');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/08/2020','dd/mm/yyyy'),'Santa Rosa 543','Amago de incendio','Inflamacion productos toxicos','6', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/08/2020','dd/mm/yyyy'),'Independencia 3255','Ca�da en salida de emergencia','Suelo con rotura','6', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/08/2020','dd/mm/yyyy'),'Salesianos 700','Ca�das desde la altura','Resbalo de escalera','6', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/08/2020','dd/mm/yyyy'),'Chilo� 9755','Contacto con la instalaci�n el�ctrica','Instalacion electrica en mal estado','7', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/08/2020','dd/mm/yyyy'),'Piramide 457','Sobresfuerzos y lesiones musculares','Lesion de espalda ','7', '10');
--julio
INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion, profesional_id_profesional, cliente_id_cliente)
values (TO_DATE('20/07/2020','dd/mm/yyyy'),'Santa Marta 0344','Descarga de camion','Trabajador se dobla tobillo por suelo roto','2', '2');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/07/2020','dd/mm/yyyy'),'Departamental 769','Amago de incendio','Derrame de productos inflamables','2', '3');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('11/07/2020','dd/mm/yyyy'),'La Aduana 1040','Caida desde escalera','Pierna quebrada','3', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('14/07/2020','dd/mm/yyyy'),'La Aduana 1040','Atropello','Accidente de trayecto','3', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/07/2020','dd/mm/yyyy'),'La Aduana 1040','Electrocutamiento','Mala gestion y uso de las herramientas de seguridad','3', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('25/07/2020','dd/mm/yyyy'),'Grecia 7325','Accidente de trayecto','esguince de tobillo','4', '5');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('26/07/2020','dd/mm/yyyy'),'Mapocho 145','Inhalacion vapor toxico','Derrame de producto toxico','4', '6');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('17/07/2020','dd/mm/yyyy'),'Macul 200','Lesion traumatica','Objeto pesado cae desde altura','5', '7');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/07/2020','dd/mm/yyyy'),'Providencia 780','Cortes y laceraciones','Corte con equipo e implemento afilado','5', '8');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('31/07/2020','dd/mm/yyyy'),'San Pablo 5778','Accidente de Trayecto','Ca�da en trayecto','6', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/07/2020','dd/mm/yyyy'),'Santiago 765','Lesiones por el uso de maquinaria y equipos','Fractura de huesos','6', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/07/2020','dd/mm/yyyy'),'Santa Rosa 543','Amago de incendio','Inflamacion productos toxicos','7', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/07/2020','dd/mm/yyyy'),'Independencia 3255','Ca�da en salida de emergencia','Suelo con rotura','7', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/07/2020','dd/mm/yyyy'),'Salesianos 700','Ca�das desde la altura','Resbalo de escalera','7', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/07/2020','dd/mm/yyyy'),'Chilo� 9755','Contacto con la instalaci�n el�ctrica','Instalacion electrica en mal estado','1', '1');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/07/2020','dd/mm/yyyy'),'Piramide 457','Sobresfuerzos y lesiones musculares','Lesion de espalda ','1', '1');
--junio
INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion, profesional_id_profesional, cliente_id_cliente)
values (TO_DATE('20/06/2020','dd/mm/yyyy'),'Santa Marta 0344','Descarga de camion','Trabajador se dobla tobillo por suelo roto','3', '2');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/06/2020','dd/mm/yyyy'),'Departamental 769','Amago de incendio','Derrame de productos inflamables','3', '3');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('11/06/2020','dd/mm/yyyy'),'La Aduana 1040','Caida desde escalera','Pierna quebrada','4', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('14/06/2020','dd/mm/yyyy'),'La Aduana 1040','Atropello','Accidente de trayecto','4', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/06/2020','dd/mm/yyyy'),'La Aduana 1040','Electrocutamiento','Mala gestion y uso de las herramientas de seguridad','4', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('25/06/2020','dd/mm/yyyy'),'Grecia 7325','Accidente de trayecto','esguince de tobillo','5', '5');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('26/06/2020','dd/mm/yyyy'),'Mapocho 145','Inhalacion vapor toxico','Derrame de producto toxico','5', '6');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('17/06/2020','dd/mm/yyyy'),'Macul 200','Lesion traumatica','Objeto pesado cae desde altura','6', '7');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/06/2020','dd/mm/yyyy'),'Providencia 780','Cortes y laceraciones','Corte con equipo e implemento afilado','6', '8');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('30/06/2020','dd/mm/yyyy'),'San Pablo 5778','Accidente de Trayecto','Ca�da en trayecto','7', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/06/2020','dd/mm/yyyy'),'Santiago 765','Lesiones por el uso de maquinaria y equipos','Fractura de huesos','7', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/06/2020','dd/mm/yyyy'),'Santa Rosa 543','Amago de incendio','Inflamacion productos toxicos','1', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/06/2020','dd/mm/yyyy'),'Independencia 3255','Ca�da en salida de emergencia','Suelo con rotura','1', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/06/2020','dd/mm/yyyy'),'Salesianos 700','Ca�das desde la altura','Resbalo de escalera','1', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/06/2020','dd/mm/yyyy'),'Chilo� 9755','Contacto con la instalaci�n el�ctrica','Instalacion electrica en mal estado','2', '1');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/06/2020','dd/mm/yyyy'),'Piramide 457','Sobresfuerzos y lesiones musculares','Lesion de espalda ','2', '1');
--mayo
INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion, profesional_id_profesional, cliente_id_cliente)
values (TO_DATE('20/05/2020','dd/mm/yyyy'),'Santa Marta 0344','Descarga de camion','Trabajador se dobla tobillo por suelo roto','4', '2');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/05/2020','dd/mm/yyyy'),'Departamental 769','Amago de incendio','Derrame de productos inflamables','4', '3');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('11/05/2020','dd/mm/yyyy'),'La Aduana 1040','Caida desde escalera','Pierna quebrada','5', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('14/05/2020','dd/mm/yyyy'),'La Aduana 1040','Atropello','Accidente de trayecto','5', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/05/2020','dd/mm/yyyy'),'La Aduana 1040','Electrocutamiento','Mala gestion y uso de las herramientas de seguridad','5', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('25/05/2020','dd/mm/yyyy'),'Grecia 7325','Accidente de trayecto','esguince de tobillo','6', '5');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('26/05/2020','dd/mm/yyyy'),'Mapocho 145','Inhalacion vapor toxico','Derrame de producto toxico','6', '6');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('17/05/2020','dd/mm/yyyy'),'Macul 200','Lesion traumatica','Objeto pesado cae desde altura','7', '7');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/05/2020','dd/mm/yyyy'),'Providencia 780','Cortes y laceraciones','Corte con equipo e implemento afilado','7', '8');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('30/05/2020','dd/mm/yyyy'),'San Pablo 5778','Accidente de Trayecto','Ca�da en trayecto','1', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/05/2020','dd/mm/yyyy'),'Santiago 765','Lesiones por el uso de maquinaria y equipos','Fractura de huesos','1', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/05/2020','dd/mm/yyyy'),'Santa Rosa 543','Amago de incendio','Inflamacion productos toxicos','2', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/05/2020','dd/mm/yyyy'),'Independencia 3255','Ca�da en salida de emergencia','Suelo con rotura','2', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/05/2020','dd/mm/yyyy'),'Salesianos 700','Ca�das desde la altura','Resbalo de escalera','2', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/05/2020','dd/mm/yyyy'),'Chilo� 9755','Contacto con la instalaci�n el�ctrica','Instalacion electrica en mal estado','3', '1');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/05/2020','dd/mm/yyyy'),'Piramide 457','Sobresfuerzos y lesiones musculares','Lesion de espalda ','3', '1');
--abril
INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion, profesional_id_profesional, cliente_id_cliente)
values (TO_DATE('20/04/2020','dd/mm/yyyy'),'Santa Marta 0344','Descarga de camion','Trabajador se dobla tobillo por suelo roto','5', '2');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/04/2020','dd/mm/yyyy'),'Departamental 769','Amago de incendio','Derrame de productos inflamables','5', '3');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('11/04/2020','dd/mm/yyyy'),'La Aduana 1040','Caida desde escalera','Pierna quebrada','6', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('14/04/2020','dd/mm/yyyy'),'La Aduana 1040','Atropello','Accidente de trayecto','6', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/04/2020','dd/mm/yyyy'),'La Aduana 1040','Electrocutamiento','Mala gestion y uso de las herramientas de seguridad','6', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('25/04/2020','dd/mm/yyyy'),'Grecia 7325','Accidente de trayecto','esguince de tobillo','7', '5');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('26/04/2020','dd/mm/yyyy'),'Mapocho 145','Inhalacion vapor toxico','Derrame de producto toxico','7', '6');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('17/04/2020','dd/mm/yyyy'),'Macul 200','Lesion traumatica','Objeto pesado cae desde altura','1', '7');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/04/2020','dd/mm/yyyy'),'Providencia 780','Cortes y laceraciones','Corte con equipo e implemento afilado','1', '8');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('30/04/2020','dd/mm/yyyy'),'San Pablo 5778','Accidente de Trayecto','Ca�da en trayecto','2', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/04/2020','dd/mm/yyyy'),'Santiago 765','Lesiones por el uso de maquinaria y equipos','Fractura de huesos','2', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/04/2020','dd/mm/yyyy'),'Santa Rosa 543','Amago de incendio','Inflamacion productos toxicos','3', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/04/2020','dd/mm/yyyy'),'Independencia 3255','Ca�da en salida de emergencia','Suelo con rotura','3', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/04/2020','dd/mm/yyyy'),'Salesianos 700','Ca�das desde la altura','Resbalo de escalera','3', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/04/2020','dd/mm/yyyy'),'Chilo� 9755','Contacto con la instalaci�n el�ctrica','Instalacion electrica en mal estado','4', '1');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/04/2020','dd/mm/yyyy'),'Piramide 457','Sobresfuerzos y lesiones musculares','Lesion de espalda ','4', '1');
--marzo
INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion, profesional_id_profesional, cliente_id_cliente)
values (TO_DATE('20/03/2020','dd/mm/yyyy'),'Santa Marta 0344','Descarga de camion','Trabajador se dobla tobillo por suelo roto','6', '2');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/03/2020','dd/mm/yyyy'),'Departamental 769','Amago de incendio','Derrame de productos inflamables','6', '3');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('11/03/2020','dd/mm/yyyy'),'La Aduana 1040','Caida desde escalera','Pierna quebrada','7', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('14/03/2020','dd/mm/yyyy'),'La Aduana 1040','Atropello','Accidente de trayecto','7', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/03/2020','dd/mm/yyyy'),'La Aduana 1040','Electrocutamiento','Mala gestion y uso de las herramientas de seguridad','7', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('25/03/2020','dd/mm/yyyy'),'Grecia 7325','Accidente de trayecto','esguince de tobillo','1', '5');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('26/03/2020','dd/mm/yyyy'),'Mapocho 145','Inhalacion vapor toxico','Derrame de producto toxico','1', '6');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('17/03/2020','dd/mm/yyyy'),'Macul 200','Lesion traumatica','Objeto pesado cae desde altura','2', '7');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/03/2020','dd/mm/yyyy'),'Providencia 780','Cortes y laceraciones','Corte con equipo e implemento afilado','2', '8');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('29/03/2020','dd/mm/yyyy'),'San Pablo 5778','Accidente de Trayecto','Ca�da en trayecto','3', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/03/2020','dd/mm/yyyy'),'Santiago 765','Lesiones por el uso de maquinaria y equipos','Fractura de huesos','3', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/03/2020','dd/mm/yyyy'),'Santa Rosa 543','Amago de incendio','Inflamacion productos toxicos','4', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/03/2020','dd/mm/yyyy'),'Independencia 3255','Ca�da en salida de emergencia','Suelo con rotura','4', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/03/2020','dd/mm/yyyy'),'Salesianos 700','Ca�das desde la altura','Resbalo de escalera','4', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/03/2020','dd/mm/yyyy'),'Chilo� 9755','Contacto con la instalaci�n el�ctrica','Instalacion electrica en mal estado','5', '1');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/03/2020','dd/mm/yyyy'),'Piramide 457','Sobresfuerzos y lesiones musculares','Lesion de espalda ','5', '1');
--febrero
INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion, profesional_id_profesional, cliente_id_cliente)
values (TO_DATE('20/02/2020','dd/mm/yyyy'),'Santa Marta 0344','Descarga de camion','Trabajador se dobla tobillo por suelo roto','7', '2');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/02/2020','dd/mm/yyyy'),'Departamental 769','Amago de incendio','Derrame de productos inflamables','7', '3');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('11/02/2020','dd/mm/yyyy'),'La Aduana 1040','Caida desde escalera','Pierna quebrada','1', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('14/02/2020','dd/mm/yyyy'),'La Aduana 1040','Atropello','Accidente de trayecto','1', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/02/2020','dd/mm/yyyy'),'La Aduana 1040','Electrocutamiento','Mala gestion y uso de las herramientas de seguridad','1', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('25/02/2020','dd/mm/yyyy'),'Grecia 7325','Accidente de trayecto','esguince de tobillo','2', '5');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('26/02/2020','dd/mm/yyyy'),'Mapocho 145','Inhalacion vapor toxico','Derrame de producto toxico','2', '6');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('17/02/2020','dd/mm/yyyy'),'Macul 200','Lesion traumatica','Objeto pesado cae desde altura','3', '7');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/02/2020','dd/mm/yyyy'),'Providencia 780','Cortes y laceraciones','Corte con equipo e implemento afilado','3', '8');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('28/02/2020','dd/mm/yyyy'),'San Pablo 5778','Accidente de Trayecto','Ca�da en trayecto','4', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/02/2020','dd/mm/yyyy'),'Santiago 765','Lesiones por el uso de maquinaria y equipos','Fractura de huesos','4', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/02/2020','dd/mm/yyyy'),'Santa Rosa 543','Amago de incendio','Inflamacion productos toxicos','5', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/02/2020','dd/mm/yyyy'),'Independencia 3255','Ca�da en salida de emergencia','Suelo con rotura','5', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/02/2020','dd/mm/yyyy'),'Salesianos 700','Ca�das desde la altura','Resbalo de escalera','5', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/02/2020','dd/mm/yyyy'),'Chilo� 9755','Contacto con la instalaci�n el�ctrica','Instalacion electrica en mal estado','6', '1');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/02/2020','dd/mm/yyyy'),'Piramide 457','Sobresfuerzos y lesiones musculares','Lesion de espalda ','6', '1');
--enero
INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion, profesional_id_profesional, cliente_id_cliente)
values (TO_DATE('20/01/2020','dd/mm/yyyy'),'Santa Marta 0344','Descarga de camion','Trabajador se dobla tobillo por suelo roto','1', '2');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/01/2020','dd/mm/yyyy'),'Departamental 769','Amago de incendio','Derrame de productos inflamables','1', '3');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('11/01/2020','dd/mm/yyyy'),'La Aduana 1040','Caida desde escalera','Pierna quebrada','2', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('14/01/2020','dd/mm/yyyy'),'La Aduana 1040','Atropello','Accidente de trayecto','2', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/01/2020','dd/mm/yyyy'),'La Aduana 1040','Electrocutamiento','Mala gestion y uso de las herramientas de seguridad','2', '4');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('25/01/2020','dd/mm/yyyy'),'Grecia 7325','Accidente de trayecto','esguince de tobillo','3', '5');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('26/01/2020','dd/mm/yyyy'),'Mapocho 145','Inhalacion vapor toxico','Derrame de producto toxico','3', '6');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('17/01/2020','dd/mm/yyyy'),'Macul 200','Lesion traumatica','Objeto pesado cae desde altura','4', '7');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/01/2020','dd/mm/yyyy'),'Providencia 780','Cortes y laceraciones','Corte con equipo e implemento afilado','4', '8');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('31/01/2020','dd/mm/yyyy'),'San Pablo 5778','Accidente de Trayecto','Ca�da en trayecto','5', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/01/2020','dd/mm/yyyy'),'Santiago 765','Lesiones por el uso de maquinaria y equipos','Fractura de huesos','5', '9');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/01/2020','dd/mm/yyyy'),'Santa Rosa 543','Amago de incendio','Inflamacion productos toxicos','6', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/01/2020','dd/mm/yyyy'),'Independencia 3255','Ca�da en salida de emergencia','Suelo con rotura','6', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/01/2020','dd/mm/yyyy'),'Salesianos 700','Ca�das desde la altura','Resbalo de escalera','6', '10');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/01/2020','dd/mm/yyyy'),'Chilo� 9755','Contacto con la instalaci�n el�ctrica','Instalacion electrica en mal estado','7', '1');

INSERT INTO reporteaccidente(fecha,direccion,labor,descripcion,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/01/2020','dd/mm/yyyy'),'Piramide 457','Sobresfuerzos y lesiones musculares','Lesion de espalda ','7', '1');
--ASESORIA
INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/08/2020 13:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Repaso de los temas de seguridad y chequeo de cumplimiento','1','1');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/08/2019 10:00','dd/mm/yyyy HH24:mi'),'Accidente','Revision de compensaciones y multas a las que se puede ver afecta la empresa','1','2');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('21/01/2020 10:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros ','2','1');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('15/01/2020 10:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros ','3','2');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('30/01/2020 15:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','4','3');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('31/01/2020 14:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','5','4');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('13/01/2020 15:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','6','5');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/02/2020 15:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','7','6');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('10/02/2020 15:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','1','7');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('15/02/2020 15:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','4','8');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('25/02/2020 16:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','6','9');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('14/02/2020 12:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','3','10');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('20/02/2020 11:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','5','5');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('10/03/2020 15:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','7','10');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('15/03/2020 15:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','2','4');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('18/03/2020 12:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','2','6');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('25/03/2020 10:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','5','9');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('16/03/2020 12:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','3','8');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('30/03/2020 16:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','4','10');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/04/2020 13:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','7','2');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('10/04/2020 17:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','3','3');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/04/2020 16:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','6','9');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('25/04/2020 16:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','5','5');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('19/04/2020 12:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','3','1');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('25/04/2020 11:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','2','2');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/05/2020 11:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','7','2');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/05/2020 11:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','6','3');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('15/05/2020 11:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','4','8');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('26/05/2020 16:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','7','1');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/05/2020 18:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','3','3');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/06/2020 18:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','5','9');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('14/06/2020 16:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','4','10');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('16/06/2020 13:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','2','1');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('17/06/2020 11:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','1','10');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('20/06/2020 14:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','3','7');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/07/2020 10:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','5','10');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/07/2020 11:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','6','1');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/07/2020 09:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','7','10');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('08/07/2020 12:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','5','3');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('13/07/2020 12:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','4','2');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('25/07/2020 12:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','7','10');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('30/07/2020 14:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','6','9');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('24/07/2020 15:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','7','5');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('07/08/2020 15:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','1','3');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('15/08/2020 15:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','5','2');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('20/08/2020 16:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','3','3');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('20/08/2020 16:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','3','3');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/09/2020 16:00','dd/mm/yyyy HH24:mi'),'Accidente','Detecci�n de peligros','2','5');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/09/2020 16:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','7','1');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/09/2020 13:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','4','2');

INSERT INTO asesoria(fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/09/2020 12:00','dd/mm/yyyy HH24:mi'),'Fiscalizacion','Medidas correctivas que debe implementar la empresa seg�n infracciones levantadas','3','8');
--CAPACITACION
INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/08/2020 12:00','dd/mm/yyyy HH24:mi'),'Seguridad en la oficina','Buenas practicas de seguridad','1','1');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/08/2020 11:00','dd/mm/yyyy HH24:mi'),'Seguridad en faena','Buenas practicas de seguridad','1','2');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/08/2020 11:00','dd/mm/yyyy HH24:mi'),'Seguridad en minas','Buenas practicas de seguridad','2','3');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/08/2020 10:00','dd/mm/yyyy HH24:mi'),'Seguridad en faena','Buenas practicas de seguridad','3','4');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/08/2020 11:00','dd/mm/yyyy HH24:mi'),'Accidentes de trayecto','Buenas practicas de seguridad','3','5');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/08/2020 12:00','dd/mm/yyyy HH24:mi'),'Alarmas de Mon�xido de Carbono','Buenas practicas de seguridad','4','6');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/08/2020 12:00','dd/mm/yyyy HH24:mi'),'Riesgos El�ctricos','Buenas practicas de seguridad','4','7');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/08/2020 12:00','dd/mm/yyyy HH24:mi'),'Extintores deIncendios','Buenas practicas de seguridad','4','7');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/08/2020 15:00','dd/mm/yyyy HH24:mi'),'Seguridad en el uso Escaleras','Buenas practicas de seguridad','5','8');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/08/2020 17:00','dd/mm/yyyy HH24:mi'),'Cables de Electricidad Elevados','Buenas practicas de seguridad','6','9');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/08/2020 17:30','dd/mm/yyyy HH24:mi'),'Seguridad en Control de Venenos','Buenas practicas de seguridad','7','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/08/2020 17:30','dd/mm/yyyy HH24:mi'),'Seguridad conPesticidas','Buenas practicas de seguridad','7','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/08/2020 12:30','dd/mm/yyyy HH24:mi'),'Primeros Auxilios en Quemaduras','Buenas practicas de seguridad','7','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/08/2020 12:30','dd/mm/yyyy HH24:mi'),'Primeros Auxilios en Envenenamientos','Buenas practicas de seguridad','6','9');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/08/2020 10:30','dd/mm/yyyy HH24:mi'),'Resbalos, Tropezones y Ca�das','Buenas practicas de seguridad','1','2');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/08/2020 10:30','dd/mm/yyyy HH24:mi'),'Seguridad en Terremotos en el Lugar de Trabajo','Buenas practicas de seguridad','3','4');
--julio
INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/07/2020 12:00','dd/mm/yyyy HH24:mi'),'Seguridad en la oficina','Buenas practicas de seguridad','2','1');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('22/07/2020 11:00','dd/mm/yyyy HH24:mi'),'Seguridad en faena','Buenas practicas de seguridad','2','2');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('31/07/2020 11:00','dd/mm/yyyy HH24:mi'),'Seguridad en minas','Buenas practicas de seguridad','3','3');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('14/07/2020 10:00','dd/mm/yyyy HH24:mi'),'Seguridad en faena','Buenas practicas de seguridad','4','4');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('22/07/2020 11:00','dd/mm/yyyy HH24:mi'),'Accidentes de trayecto','Buenas practicas de seguridad','4','5');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/07/2020 12:00','dd/mm/yyyy HH24:mi'),'Alarmas de Mon�xido de Carbono','Buenas practicas de seguridad','5','6');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('15/07/2020 12:00','dd/mm/yyyy HH24:mi'),'Riesgos El�ctricos','Buenas practicas de seguridad','5','7');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/07/2020 12:00','dd/mm/yyyy HH24:mi'),'Extintores deIncendios','Buenas practicas de seguridad','5','7');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/07/2020 15:00','dd/mm/yyyy HH24:mi'),'Seguridad en el uso Escaleras','Buenas practicas de seguridad','6','8');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/07/2020 17:00','dd/mm/yyyy HH24:mi'),'Cables de Electricidad Elevados','Buenas practicas de seguridad','7','9');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('29/07/2020 17:30','dd/mm/yyyy HH24:mi'),'Seguridad en Control de Venenos','Buenas practicas de seguridad','1','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/07/2020 17:30','dd/mm/yyyy HH24:mi'),'Seguridad conPesticidas','Buenas practicas de seguridad','1','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/07/2020 12:30','dd/mm/yyyy HH24:mi'),'Primeros Auxilios en Quemaduras','Buenas practicas de seguridad','1','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/07/2020 12:30','dd/mm/yyyy HH24:mi'),'Primeros Auxilios en Envenenamientos','Buenas practicas de seguridad','1','9');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/07/2020 10:30','dd/mm/yyyy HH24:mi'),'Resbalos, Tropezones y Ca�das','Buenas practicas de seguridad','1','2');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('21/07/2020 10:30','dd/mm/yyyy HH24:mi'),'Seguridad en Terremotos en el Lugar de Trabajo','Buenas practicas de seguridad','1','4');
--junio
INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/06/2020 12:00','dd/mm/yyyy HH24:mi'),'Seguridad en la oficina','Buenas practicas de seguridad','3','1');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('22/06/2020 11:00','dd/mm/yyyy HH24:mi'),'Seguridad en faena','Buenas practicas de seguridad','3','2');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('30/06/2020 11:00','dd/mm/yyyy HH24:mi'),'Seguridad en minas','Buenas practicas de seguridad','4','3');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('14/06/2020 10:00','dd/mm/yyyy HH24:mi'),'Seguridad en faena','Buenas practicas de seguridad','5','4');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('22/06/2020 11:00','dd/mm/yyyy HH24:mi'),'Accidentes de trayecto','Buenas practicas de seguridad','5','5');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/06/2020 12:00','dd/mm/yyyy HH24:mi'),'Alarmas de Mon�xido de Carbono','Buenas practicas de seguridad','6','6');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('15/06/2020 12:00','dd/mm/yyyy HH24:mi'),'Riesgos El�ctricos','Buenas practicas de seguridad','6','7');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/06/2020 12:00','dd/mm/yyyy HH24:mi'),'Extintores deIncendios','Buenas practicas de seguridad','6','7');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/06/2020 15:00','dd/mm/yyyy HH24:mi'),'Seguridad en el uso Escaleras','Buenas practicas de seguridad','7','8');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/06/2020 17:00','dd/mm/yyyy HH24:mi'),'Cables de Electricidad Elevados','Buenas practicas de seguridad','1','9');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('29/06/2020 17:30','dd/mm/yyyy HH24:mi'),'Seguridad en Control de Venenos','Buenas practicas de seguridad','2','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/06/2020 17:30','dd/mm/yyyy HH24:mi'),'Seguridad conPesticidas','Buenas practicas de seguridad','2','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/06/2020 12:30','dd/mm/yyyy HH24:mi'),'Primeros Auxilios en Quemaduras','Buenas practicas de seguridad','2','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/06/2020 12:30','dd/mm/yyyy HH24:mi'),'Primeros Auxilios en Envenenamientos','Buenas practicas de seguridad','2','9');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/06/2020 10:30','dd/mm/yyyy HH24:mi'),'Resbalos, Tropezones y Ca�das','Buenas practicas de seguridad','2','2');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('21/06/2020 10:30','dd/mm/yyyy HH24:mi'),'Seguridad en Terremotos en el Lugar de Trabajo','Buenas practicas de seguridad','2','4');
--mayo
INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/05/2020 12:00','dd/mm/yyyy HH24:mi'),'Seguridad en la oficina','Buenas practicas de seguridad','4','1');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('22/05/2020 11:00','dd/mm/yyyy HH24:mi'),'Seguridad en faena','Buenas practicas de seguridad','4','2');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('30/05/2020 11:00','dd/mm/yyyy HH24:mi'),'Seguridad en minas','Buenas practicas de seguridad','5','3');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('14/05/2020 10:00','dd/mm/yyyy HH24:mi'),'Seguridad en faena','Buenas practicas de seguridad','6','4');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('22/05/2020 11:00','dd/mm/yyyy HH24:mi'),'Accidentes de trayecto','Buenas practicas de seguridad','6','5');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/05/2020 12:00','dd/mm/yyyy HH24:mi'),'Alarmas de Mon�xido de Carbono','Buenas practicas de seguridad','7','6');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('15/05/2020 12:00','dd/mm/yyyy HH24:mi'),'Riesgos El�ctricos','Buenas practicas de seguridad','7','7');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/05/2020 12:00','dd/mm/yyyy HH24:mi'),'Extintores deIncendios','Buenas practicas de seguridad','7','7');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/05/2020 15:00','dd/mm/yyyy HH24:mi'),'Seguridad en el uso Escaleras','Buenas practicas de seguridad','1','8');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/05/2020 17:00','dd/mm/yyyy HH24:mi'),'Cables de Electricidad Elevados','Buenas practicas de seguridad','2','9');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('29/05/2020 17:30','dd/mm/yyyy HH24:mi'),'Seguridad en Control de Venenos','Buenas practicas de seguridad','3','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/05/2020 17:30','dd/mm/yyyy HH24:mi'),'Seguridad conPesticidas','Buenas practicas de seguridad','3','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/05/2020 12:30','dd/mm/yyyy HH24:mi'),'Primeros Auxilios en Quemaduras','Buenas practicas de seguridad','3','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/05/2020 12:30','dd/mm/yyyy HH24:mi'),'Primeros Auxilios en Envenenamientos','Buenas practicas de seguridad','3','9');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/05/2020 10:30','dd/mm/yyyy HH24:mi'),'Resbalos, Tropezones y Ca�das','Buenas practicas de seguridad','3','2');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('21/05/2020 10:30','dd/mm/yyyy HH24:mi'),'Seguridad en Terremotos en el Lugar de Trabajo','Buenas practicas de seguridad','3','4');
--abril
INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/04/2020 12:00','dd/mm/yyyy HH24:mi'),'Seguridad en la oficina','Buenas practicas de seguridad','5','1');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('22/04/2020 11:00','dd/mm/yyyy HH24:mi'),'Seguridad en faena','Buenas practicas de seguridad','5','2');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('30/04/2020 11:00','dd/mm/yyyy HH24:mi'),'Seguridad en minas','Buenas practicas de seguridad','6','3');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('14/04/2020 10:00','dd/mm/yyyy HH24:mi'),'Seguridad en faena','Buenas practicas de seguridad','7','4');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('22/04/2020 11:00','dd/mm/yyyy HH24:mi'),'Accidentes de trayecto','Buenas practicas de seguridad','7','5');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/04/2020 12:00','dd/mm/yyyy HH24:mi'),'Alarmas de Mon�xido de Carbono','Buenas practicas de seguridad','1','6');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('15/04/2020 12:00','dd/mm/yyyy HH24:mi'),'Riesgos El�ctricos','Buenas practicas de seguridad','1','7');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/04/2020 12:00','dd/mm/yyyy HH24:mi'),'Extintores deIncendios','Buenas practicas de seguridad','1','7');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/04/2020 15:00','dd/mm/yyyy HH24:mi'),'Seguridad en el uso Escaleras','Buenas practicas de seguridad','2','8');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/04/2020 17:00','dd/mm/yyyy HH24:mi'),'Cables de Electricidad Elevados','Buenas practicas de seguridad','3','9');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('29/04/2020 17:30','dd/mm/yyyy HH24:mi'),'Seguridad en Control de Venenos','Buenas practicas de seguridad','4','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/04/2020 17:30','dd/mm/yyyy HH24:mi'),'Seguridad conPesticidas','Buenas practicas de seguridad','4','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/04/2020 12:30','dd/mm/yyyy HH24:mi'),'Primeros Auxilios en Quemaduras','Buenas practicas de seguridad','4','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/04/2020 12:30','dd/mm/yyyy HH24:mi'),'Primeros Auxilios en Envenenamientos','Buenas practicas de seguridad','4','9');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/04/2020 10:30','dd/mm/yyyy HH24:mi'),'Resbalos, Tropezones y Ca�das','Buenas practicas de seguridad','4','2');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('21/04/2020 10:30','dd/mm/yyyy HH24:mi'),'Seguridad en Terremotos en el Lugar de Trabajo','Buenas practicas de seguridad','4','4');
--marzo
INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/03/2020 12:00','dd/mm/yyyy HH24:mi'),'Seguridad en la oficina','Buenas practicas de seguridad','6','1');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('22/03/2020 11:00','dd/mm/yyyy HH24:mi'),'Seguridad en faena','Buenas practicas de seguridad','6','2');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('30/03/2020 11:00','dd/mm/yyyy HH24:mi'),'Seguridad en minas','Buenas practicas de seguridad','7','3');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('14/03/2020 10:00','dd/mm/yyyy HH24:mi'),'Seguridad en faena','Buenas practicas de seguridad','1','4');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('22/03/2020 11:00','dd/mm/yyyy HH24:mi'),'Accidentes de trayecto','Buenas practicas de seguridad','1','5');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/03/2020 12:00','dd/mm/yyyy HH24:mi'),'Alarmas de Mon�xido de Carbono','Buenas practicas de seguridad','2','6');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('15/03/2020 12:00','dd/mm/yyyy HH24:mi'),'Riesgos El�ctricos','Buenas practicas de seguridad','2','7');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/03/2020 12:00','dd/mm/yyyy HH24:mi'),'Extintores deIncendios','Buenas practicas de seguridad','2','7');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/03/2020 15:00','dd/mm/yyyy HH24:mi'),'Seguridad en el uso Escaleras','Buenas practicas de seguridad','3','8');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/03/2020 17:00','dd/mm/yyyy HH24:mi'),'Cables de Electricidad Elevados','Buenas practicas de seguridad','4','9');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('29/03/2020 17:30','dd/mm/yyyy HH24:mi'),'Seguridad en Control de Venenos','Buenas practicas de seguridad','5','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/03/2020 17:30','dd/mm/yyyy HH24:mi'),'Seguridad conPesticidas','Buenas practicas de seguridad','5','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/03/2020 12:30','dd/mm/yyyy HH24:mi'),'Primeros Auxilios en Quemaduras','Buenas practicas de seguridad','5','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/03/2020 12:30','dd/mm/yyyy HH24:mi'),'Primeros Auxilios en Envenenamientos','Buenas practicas de seguridad','5','9');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/03/2020 10:30','dd/mm/yyyy HH24:mi'),'Resbalos, Tropezones y Ca�das','Buenas practicas de seguridad','5','2');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('21/03/2020 10:30','dd/mm/yyyy HH24:mi'),'Seguridad en Terremotos en el Lugar de Trabajo','Buenas practicas de seguridad','5','4');
--febrero
INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/02/2020 12:00','dd/mm/yyyy HH24:mi'),'Seguridad en la oficina','Buenas practicas de seguridad','7','1');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('22/02/2020 11:00','dd/mm/yyyy HH24:mi'),'Seguridad en faena','Buenas practicas de seguridad','7','2');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('28/02/2020 11:00','dd/mm/yyyy HH24:mi'),'Seguridad en minas','Buenas practicas de seguridad','1','3');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('14/02/2020 10:00','dd/mm/yyyy HH24:mi'),'Seguridad en faena','Buenas practicas de seguridad','2','4');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('22/02/2020 11:00','dd/mm/yyyy HH24:mi'),'Accidentes de trayecto','Buenas practicas de seguridad','2','5');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/02/2020 12:00','dd/mm/yyyy HH24:mi'),'Alarmas de Mon�xido de Carbono','Buenas practicas de seguridad','3','6');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('15/02/2020 12:00','dd/mm/yyyy HH24:mi'),'Riesgos El�ctricos','Buenas practicas de seguridad','3','7');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/02/2020 12:00','dd/mm/yyyy HH24:mi'),'Extintores deIncendios','Buenas practicas de seguridad','3','7');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/02/2020 15:00','dd/mm/yyyy HH24:mi'),'Seguridad en el uso Escaleras','Buenas practicas de seguridad','4','8');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/02/2020 17:00','dd/mm/yyyy HH24:mi'),'Cables de Electricidad Elevados','Buenas practicas de seguridad','5','9');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/02/2020 17:30','dd/mm/yyyy HH24:mi'),'Seguridad en Control de Venenos','Buenas practicas de seguridad','6','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/02/2020 17:30','dd/mm/yyyy HH24:mi'),'Seguridad conPesticidas','Buenas practicas de seguridad','6','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/02/2020 12:30','dd/mm/yyyy HH24:mi'),'Primeros Auxilios en Quemaduras','Buenas practicas de seguridad','6','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/02/2020 12:30','dd/mm/yyyy HH24:mi'),'Primeros Auxilios en Envenenamientos','Buenas practicas de seguridad','6','9');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/02/2020 10:30','dd/mm/yyyy HH24:mi'),'Resbalos, Tropezones y Ca�das','Buenas practicas de seguridad','6','2');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('21/02/2020 10:30','dd/mm/yyyy HH24:mi'),'Seguridad en Terremotos en el Lugar de Trabajo','Buenas practicas de seguridad','6','4');
--enero
INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/01/2020 12:00','dd/mm/yyyy HH24:mi'),'Seguridad en la oficina','Buenas practicas de seguridad','1','1');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('22/01/2020 11:00','dd/mm/yyyy HH24:mi'),'Seguridad en faena','Buenas practicas de seguridad','1','2');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('28/01/2020 11:00','dd/mm/yyyy HH24:mi'),'Seguridad en minas','Buenas practicas de seguridad','2','3');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('14/01/2020 10:00','dd/mm/yyyy HH24:mi'),'Seguridad en faena','Buenas practicas de seguridad','3','4');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('22/01/2020 11:00','dd/mm/yyyy HH24:mi'),'Accidentes de trayecto','Buenas practicas de seguridad','3','5');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('06/01/2020 12:00','dd/mm/yyyy HH24:mi'),'Alarmas de Mon�xido de Carbono','Buenas practicas de seguridad','4','6');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('15/01/2020 12:00','dd/mm/yyyy HH24:mi'),'Riesgos El�ctricos','Buenas practicas de seguridad','4','7');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/01/2020 12:00','dd/mm/yyyy HH24:mi'),'Extintores deIncendios','Buenas practicas de seguridad','4','7');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/01/2020 15:00','dd/mm/yyyy HH24:mi'),'Seguridad en el uso Escaleras','Buenas practicas de seguridad','5','8');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/01/2020 17:00','dd/mm/yyyy HH24:mi'),'Cables de Electricidad Elevados','Buenas practicas de seguridad','6','9');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/01/2020 17:30','dd/mm/yyyy HH24:mi'),'Seguridad en Control de Venenos','Buenas practicas de seguridad','7','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/01/2020 17:30','dd/mm/yyyy HH24:mi'),'Seguridad conPesticidas','Buenas practicas de seguridad','7','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('04/01/2020 12:30','dd/mm/yyyy HH24:mi'),'Primeros Auxilios en Quemaduras','Buenas practicas de seguridad','7','10');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/01/2020 12:30','dd/mm/yyyy HH24:mi'),'Primeros Auxilios en Envenenamientos','Buenas practicas de seguridad','7','9');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('23/01/2020 10:30','dd/mm/yyyy HH24:mi'),'Resbalos, Tropezones y Ca�das','Buenas practicas de seguridad','7','2');

INSERT INTO capacitacion(fechayhora,tema,contenido,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('21/01/2020 10:30','dd/mm/yyyy HH24:mi'),'Seguridad en Terremotos en el Lugar de Trabajo','Buenas practicas de seguridad','7','4');
--FACTURA
INSERT INTO factura(fechacobro,fechavencimiento,extras, impuestos, subtotal, total, cliente_id_cliente)
values (TO_DATE('01/08/2020','dd/mm/yyyy'), TO_DATE('06/08/2020','dd/mm/yyyy'),300000,475000,2200000,2975000, '1');

INSERT INTO factura(fechacobro,fechavencimiento,extras, impuestos,subtotal, total, cliente_id_cliente)
values (TO_DATE('01/08/2020','dd/mm/yyyy'), TO_DATE('03/08/2020','dd/mm/yyyy'),400000,399000,1700000,2499000, '2');

INSERT INTO factura(fechacobro,fechavencimiento,extras, impuestos,subtotal, total, cliente_id_cliente)
values (TO_DATE('01/08/2020','dd/mm/yyyy'), TO_DATE('02/08/2020','dd/mm/yyyy'),100000,171000,800000,1071000, '3');

INSERT INTO factura(fechacobro,fechavencimiento,extras, impuestos,subtotal, total, cliente_id_cliente)
values (TO_DATE('01/08/2020','dd/mm/yyyy'), TO_DATE('04/08/2020','dd/mm/yyyy'),200000,247000,1100000,1547000, '4');

INSERT INTO factura(fechacobro,fechavencimiento,extras, impuestos,subtotal, total, cliente_id_cliente)
values (TO_DATE('01/08/2020','dd/mm/yyyy'), TO_DATE('24/08/2020','dd/mm/yyyy'),500000,285000,1000000,1785000, '5');

--DETALLE FACTURA
INSERT INTO detallefactura(nombre,precio, cantidad, factura_id_factura)
values ('capacitacion', 400000,2,'1');

INSERT INTO detallefactura(nombre,precio, cantidad, factura_id_factura)
values ('asesoria', 300000,4,'1');

INSERT INTO detallefactura(nombre,precio, cantidad, factura_id_factura)
values ('callcenter', 200000,1,'1');

INSERT INTO detallefactura(nombre,precio, cantidad, factura_id_factura)
values ('asesoria', 300000,3,'2');

INSERT INTO detallefactura(nombre,precio, cantidad, factura_id_factura)
values ('capacitacion', 400000,2,'2');

INSERT INTO detallefactura(nombre,precio, cantidad, factura_id_factura)
values ('callcenter', 400000,1,'3');

INSERT INTO detallefactura(nombre,precio, cantidad, factura_id_factura)
values ('asesoria', 200000,2,'3');

INSERT INTO detallefactura(nombre,precio, cantidad, factura_id_factura)
values ('callcenter', 300000,1,'4');

INSERT INTO detallefactura(nombre,precio, cantidad, factura_id_factura)
values ('asesoria', 100000,2,'4');

INSERT INTO detallefactura(nombre,precio, cantidad, factura_id_factura)
values ('capacitacion', 200000,3,'4');

INSERT INTO detallefactura(nombre,precio, cantidad, factura_id_factura)
values ('asesoria', 500000,2,'5');

--ADMINISTRADOR
INSERT INTO administrador (nombre,usuario_id_usuario,usuario_nickname)
values ('Jorge Castillo',26,'jorgecastillo');

--ASESORIA EXTRA
INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional, cliente_id_cliente)
values (TO_DATE('02/08/2020 13:00','dd/mm/yyyy HH24:mi'),'Asesor�a autocuidado','Autocuidado laboral de trabajadores','1' ,'1');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/08/2020 17:00','dd/mm/yyyy HH24:mi'),'Chequeo de instalaciones','Revision a nuevas instalaciones','1', '2');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('20/08/2020 10:00','dd/mm/yyyy HH24:mi'),'Asesor�a emergencias','Se solicita asesor�a para salidas de emergencia','2', '3');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional, cliente_id_cliente)
values (TO_DATE('25/01/2020 13:00','dd/mm/yyyy HH24:mi'),'Asesor�a autocuidado','Autocuidado laboral de trabajadores','2' ,'2');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('26/01/2020 17:00','dd/mm/yyyy HH24:mi'),'Chequeo de instalaciones','Revision a nuevas instalaciones','3', '3');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/01/2020 10:00','dd/mm/yyyy HH24:mi'),'Asesor�a emergencias','Se solicita asesor�a para salidas de emergencia','3', '1');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional, cliente_id_cliente)
values (TO_DATE('24/02/2020 13:00','dd/mm/yyyy HH24:mi'),'Asesor�a autocuidado','Autocuidado laboral de trabajadores','1' ,'10');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('26/02/2020 17:00','dd/mm/yyyy HH24:mi'),'Chequeo de instalaciones','Revision a nuevas instalaciones','5', '8');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/02/2020 10:00','dd/mm/yyyy HH24:mi'),'Asesor�a emergencias','Se solicita asesor�a para salidas de emergencia','7', '9');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional, cliente_id_cliente)
values (TO_DATE('24/03/2020 13:00','dd/mm/yyyy HH24:mi'),'Asesor�a autocuidado','Autocuidado laboral de trabajadores','4' ,'7');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('26/03/2020 17:00','dd/mm/yyyy HH24:mi'),'Chequeo de instalaciones','Revision a nuevas instalaciones','6', '6');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/03/2020 10:00','dd/mm/yyyy HH24:mi'),'Asesor�a emergencias','Se solicita asesor�a para salidas de emergencia','5', '5');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional, cliente_id_cliente)
values (TO_DATE('24/04/2020 13:00','dd/mm/yyyy HH24:mi'),'Asesor�a autocuidado','Autocuidado laboral de trabajadores','3' ,'1');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('26/04/2020 17:00','dd/mm/yyyy HH24:mi'),'Chequeo de instalaciones','Revision a nuevas instalaciones','4', '9');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/04/2020 10:00','dd/mm/yyyy HH24:mi'),'Asesor�a emergencias','Se solicita asesor�a para salidas de emergencia','4', '6');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional, cliente_id_cliente)
values (TO_DATE('24/05/2020 13:00','dd/mm/yyyy HH24:mi'),'Asesor�a autocuidado','Autocuidado laboral de trabajadores','2' ,'10');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('26/05/2020 17:00','dd/mm/yyyy HH24:mi'),'Chequeo de instalaciones','Revision a nuevas instalaciones','7', '5');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/05/2020 10:00','dd/mm/yyyy HH24:mi'),'Asesor�a emergencias','Se solicita asesor�a para salidas de emergencia','5', '3');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional, cliente_id_cliente)
values (TO_DATE('24/06/2020 13:00','dd/mm/yyyy HH24:mi'),'Asesor�a autocuidado','Autocuidado laboral de trabajadores','1' ,'1');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('26/06/2020 17:00','dd/mm/yyyy HH24:mi'),'Chequeo de instalaciones','Revision a nuevas instalaciones','2', '2');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/06/2020 10:00','dd/mm/yyyy HH24:mi'),'Asesor�a emergencias','Se solicita asesor�a para salidas de emergencia','3', '6');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional, cliente_id_cliente)
values (TO_DATE('24/07/2020 13:00','dd/mm/yyyy HH24:mi'),'Asesor�a autocuidado','Autocuidado laboral de trabajadores','4' ,'1');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('26/07/2020 17:00','dd/mm/yyyy HH24:mi'),'Chequeo de instalaciones','Revision a nuevas instalaciones','2', '10');

INSERT INTO asesoriaextra (fechayhora,motivo,detalle,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('27/07/2020 10:00','dd/mm/yyyy HH24:mi'),'Asesor�a emergencias','Se solicita asesor�a para salidas de emergencia','7', '9');

--VISITA

--ENERO

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('05/01/2020 12:00','dd/mm/yyyy HH24:mi'),1,1,10);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('06/01/2020 10:00','dd/mm/yyyy HH24:mi'),1,2,9);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('07/01/2020 16:00','dd/mm/yyyy HH24:mi'),1,3,8);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('08/01/2020 11:00','dd/mm/yyyy HH24:mi'),1,4,7);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('09/01/2020 10:00','dd/mm/yyyy HH24:mi'),1,5,6);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('10/01/2020 15:00','dd/mm/yyyy HH24:mi'),1,6,5);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('11/01/2020 14:00','dd/mm/yyyy HH24:mi'),1,7,4);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('12/01/2020 12:00','dd/mm/yyyy HH24:mi'),1,7,3);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('13/01/2020 15:00','dd/mm/yyyy HH24:mi'),1,6,2);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('14/01/2020 14:00','dd/mm/yyyy HH24:mi'),1,5,1);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('15/01/2020 12:00','dd/mm/yyyy HH24:mi'),2,1,10);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('16/01/2020 10:00','dd/mm/yyyy HH24:mi'),2,2,9);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('17/01/2020 16:00','dd/mm/yyyy HH24:mi'),2,3,8);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('18/01/2020 11:00','dd/mm/yyyy HH24:mi'),2,4,7);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('19/01/2020 10:00','dd/mm/yyyy HH24:mi'),2,5,6);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('20/01/2020 15:00','dd/mm/yyyy HH24:mi'),2,6,5);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('21/01/2020 14:00','dd/mm/yyyy HH24:mi'),2,2,4);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('22/01/2020 12:00','dd/mm/yyyy HH24:mi'),2,7,3);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('23/01/2020 15:00','dd/mm/yyyy HH24:mi'),2,6,2);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('24/01/2020 14:00','dd/mm/yyyy HH24:mi'),2,5,1);

--FEBRERO

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('05/02/2020 12:00','dd/mm/yyyy HH24:mi'),1,1,10);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('06/02/2020 10:00','dd/mm/yyyy HH24:mi'),1,2,9);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('07/02/2020 16:00','dd/mm/yyyy HH24:mi'),1,3,8);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('08/02/2020 11:00','dd/mm/yyyy HH24:mi'),1,4,7);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('09/02/2020 10:00','dd/mm/yyyy HH24:mi'),1,5,6);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('10/02/2020 15:00','dd/mm/yyyy HH24:mi'),1,6,5);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('11/02/2020 14:00','dd/mm/yyyy HH24:mi'),1,7,4);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('12/02/2020 12:00','dd/mm/yyyy HH24:mi'),1,7,3);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('13/02/2020 15:00','dd/mm/yyyy HH24:mi'),1,6,2);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('14/02/2020 14:00','dd/mm/yyyy HH24:mi'),1,5,1);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('15/02/2020 12:00','dd/mm/yyyy HH24:mi'),2,1,10);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('16/02/2020 10:00','dd/mm/yyyy HH24:mi'),2,2,9);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('17/02/2020 16:00','dd/mm/yyyy HH24:mi'),2,3,8);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('18/02/2020 11:00','dd/mm/yyyy HH24:mi'),2,4,7);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('19/02/2020 10:00','dd/mm/yyyy HH24:mi'),2,5,6);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('20/02/2020 15:00','dd/mm/yyyy HH24:mi'),2,6,5);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('21/02/2020 14:00','dd/mm/yyyy HH24:mi'),2,2,4);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('22/02/2020 12:00','dd/mm/yyyy HH24:mi'),2,7,3);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('23/02/2020 15:00','dd/mm/yyyy HH24:mi'),2,6,2);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('24/02/2020 14:00','dd/mm/yyyy HH24:mi'),2,5,1);

--MARZO

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('05/03/2020 12:00','dd/mm/yyyy HH24:mi'),1,1,10);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('06/03/2020 10:00','dd/mm/yyyy HH24:mi'),1,2,9);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('07/03/2020 16:00','dd/mm/yyyy HH24:mi'),1,3,8);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('08/03/2020 11:00','dd/mm/yyyy HH24:mi'),1,4,7);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('09/03/2020 10:00','dd/mm/yyyy HH24:mi'),1,5,6);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('10/03/2020 15:00','dd/mm/yyyy HH24:mi'),1,6,5);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('11/03/2020 14:00','dd/mm/yyyy HH24:mi'),1,7,4);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('12/03/2020 12:00','dd/mm/yyyy HH24:mi'),1,7,3);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('13/03/2020 15:00','dd/mm/yyyy HH24:mi'),1,6,2);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('14/03/2020 14:00','dd/mm/yyyy HH24:mi'),1,5,1);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('15/03/2020 12:00','dd/mm/yyyy HH24:mi'),2,1,10);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('16/03/2020 10:00','dd/mm/yyyy HH24:mi'),2,2,9);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('17/03/2020 16:00','dd/mm/yyyy HH24:mi'),2,3,8);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('18/03/2020 11:00','dd/mm/yyyy HH24:mi'),2,4,7);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('19/03/2020 10:00','dd/mm/yyyy HH24:mi'),2,5,6);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('20/03/2020 15:00','dd/mm/yyyy HH24:mi'),2,6,5);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('21/03/2020 14:00','dd/mm/yyyy HH24:mi'),2,2,4);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('22/03/2020 12:00','dd/mm/yyyy HH24:mi'),2,7,3);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('23/03/2020 15:00','dd/mm/yyyy HH24:mi'),2,6,2);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('24/03/2020 14:00','dd/mm/yyyy HH24:mi'),2,5,1);

--ABRIL

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('05/04/2020 12:00','dd/mm/yyyy HH24:mi'),1,1,10);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('06/04/2020 10:00','dd/mm/yyyy HH24:mi'),1,2,9);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('07/04/2020 16:00','dd/mm/yyyy HH24:mi'),1,3,8);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('08/04/2020 11:00','dd/mm/yyyy HH24:mi'),1,4,7);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('09/04/2020 10:00','dd/mm/yyyy HH24:mi'),1,5,6);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('10/04/2020 15:00','dd/mm/yyyy HH24:mi'),1,6,5);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('11/04/2020 14:00','dd/mm/yyyy HH24:mi'),1,7,4);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('12/04/2020 12:00','dd/mm/yyyy HH24:mi'),1,7,3);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('13/04/2020 15:00','dd/mm/yyyy HH24:mi'),1,6,2);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('14/04/2020 14:00','dd/mm/yyyy HH24:mi'),1,5,1);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('15/04/2020 12:00','dd/mm/yyyy HH24:mi'),2,1,10);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('16/04/2020 10:00','dd/mm/yyyy HH24:mi'),2,2,9);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('17/04/2020 16:00','dd/mm/yyyy HH24:mi'),2,3,8);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('18/04/2020 11:00','dd/mm/yyyy HH24:mi'),2,4,7);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('19/04/2020 10:00','dd/mm/yyyy HH24:mi'),2,5,6);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('20/04/2020 15:00','dd/mm/yyyy HH24:mi'),2,6,5);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('21/04/2020 14:00','dd/mm/yyyy HH24:mi'),2,2,4);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('22/04/2020 12:00','dd/mm/yyyy HH24:mi'),2,7,3);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('23/04/2020 15:00','dd/mm/yyyy HH24:mi'),2,6,2);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('24/04/2020 14:00','dd/mm/yyyy HH24:mi'),2,5,1);

--MAYO

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('05/05/2020 12:00','dd/mm/yyyy HH24:mi'),1,1,10);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('06/05/2020 10:00','dd/mm/yyyy HH24:mi'),1,2,9);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('07/05/2020 16:00','dd/mm/yyyy HH24:mi'),1,3,8);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('08/05/2020 11:00','dd/mm/yyyy HH24:mi'),1,4,7);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('09/05/2020 10:00','dd/mm/yyyy HH24:mi'),1,5,6);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('10/05/2020 15:00','dd/mm/yyyy HH24:mi'),1,6,5);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('11/05/2020 14:00','dd/mm/yyyy HH24:mi'),1,7,4);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('12/05/2020 12:00','dd/mm/yyyy HH24:mi'),1,7,3);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('13/05/2020 15:00','dd/mm/yyyy HH24:mi'),1,6,2);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('14/05/2020 14:00','dd/mm/yyyy HH24:mi'),1,5,1);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('15/05/2020 12:00','dd/mm/yyyy HH24:mi'),2,1,10);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('16/05/2020 10:00','dd/mm/yyyy HH24:mi'),2,2,9);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('17/05/2020 16:00','dd/mm/yyyy HH24:mi'),2,3,8);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('18/05/2020 11:00','dd/mm/yyyy HH24:mi'),2,4,7);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('19/05/2020 10:00','dd/mm/yyyy HH24:mi'),2,5,6);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('20/05/2020 15:00','dd/mm/yyyy HH24:mi'),2,6,5);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('21/05/2020 14:00','dd/mm/yyyy HH24:mi'),2,2,4);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('22/05/2020 12:00','dd/mm/yyyy HH24:mi'),2,7,3);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('23/05/2020 15:00','dd/mm/yyyy HH24:mi'),2,6,2);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('24/05/2020 14:00','dd/mm/yyyy HH24:mi'),2,5,1);

--JUNIO

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('05/06/2020 12:00','dd/mm/yyyy HH24:mi'),1,1,10);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('06/06/2020 10:00','dd/mm/yyyy HH24:mi'),1,2,9);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('07/06/2020 16:00','dd/mm/yyyy HH24:mi'),1,3,8);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('08/06/2020 11:00','dd/mm/yyyy HH24:mi'),1,4,7);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('09/06/2020 10:00','dd/mm/yyyy HH24:mi'),1,5,6);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('10/06/2020 15:00','dd/mm/yyyy HH24:mi'),1,6,5);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('11/06/2020 14:00','dd/mm/yyyy HH24:mi'),1,7,4);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('12/06/2020 12:00','dd/mm/yyyy HH24:mi'),1,7,3);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('13/06/2020 15:00','dd/mm/yyyy HH24:mi'),1,6,2);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('14/06/2020 14:00','dd/mm/yyyy HH24:mi'),1,5,1);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('15/06/2020 12:00','dd/mm/yyyy HH24:mi'),2,1,10);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('16/06/2020 10:00','dd/mm/yyyy HH24:mi'),2,2,9);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('17/06/2020 16:00','dd/mm/yyyy HH24:mi'),2,3,8);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('18/06/2020 11:00','dd/mm/yyyy HH24:mi'),2,4,7);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('19/06/2020 10:00','dd/mm/yyyy HH24:mi'),2,5,6);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('20/06/2020 15:00','dd/mm/yyyy HH24:mi'),2,6,5);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('21/06/2020 14:00','dd/mm/yyyy HH24:mi'),2,2,4);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('22/06/2020 12:00','dd/mm/yyyy HH24:mi'),2,7,3);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('23/06/2020 15:00','dd/mm/yyyy HH24:mi'),2,6,2);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('24/06/2020 14:00','dd/mm/yyyy HH24:mi'),2,5,1);

--JULIO

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('05/07/2020 12:00','dd/mm/yyyy HH24:mi'),1,1,10);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('06/07/2020 10:00','dd/mm/yyyy HH24:mi'),1,2,9);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('07/07/2020 16:00','dd/mm/yyyy HH24:mi'),1,3,8);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('08/07/2020 11:00','dd/mm/yyyy HH24:mi'),1,4,7);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('09/07/2020 10:00','dd/mm/yyyy HH24:mi'),1,5,6);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('10/07/2020 15:00','dd/mm/yyyy HH24:mi'),1,6,5);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('11/07/2020 14:00','dd/mm/yyyy HH24:mi'),1,7,4);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('12/07/2020 12:00','dd/mm/yyyy HH24:mi'),1,7,3);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('13/07/2020 15:00','dd/mm/yyyy HH24:mi'),1,6,2);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('14/07/2020 14:00','dd/mm/yyyy HH24:mi'),1,5,1);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('15/07/2020 12:00','dd/mm/yyyy HH24:mi'),2,1,10);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('16/07/2020 10:00','dd/mm/yyyy HH24:mi'),2,2,9);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('17/07/2020 16:00','dd/mm/yyyy HH24:mi'),2,3,8);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('18/07/2020 11:00','dd/mm/yyyy HH24:mi'),2,4,7);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('19/07/2020 10:00','dd/mm/yyyy HH24:mi'),2,5,6);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('20/07/2020 15:00','dd/mm/yyyy HH24:mi'),2,6,5);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('21/07/2020 14:00','dd/mm/yyyy HH24:mi'),2,2,4);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('22/07/2020 12:00','dd/mm/yyyy HH24:mi'),2,7,3);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('23/07/2020 15:00','dd/mm/yyyy HH24:mi'),2,6,2);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('24/07/2020 14:00','dd/mm/yyyy HH24:mi'),2,5,1);

--AGOSTO

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('05/08/2020 12:00','dd/mm/yyyy HH24:mi'),1,1,10);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('06/08/2020 10:00','dd/mm/yyyy HH24:mi'),1,2,9);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('07/08/2020 16:00','dd/mm/yyyy HH24:mi'),1,3,8);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('08/08/2020 11:00','dd/mm/yyyy HH24:mi'),1,4,7);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('09/08/2020 10:00','dd/mm/yyyy HH24:mi'),1,5,6);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('10/08/2020 15:00','dd/mm/yyyy HH24:mi'),1,6,5);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('11/08/2020 14:00','dd/mm/yyyy HH24:mi'),1,7,4);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('12/08/2020 12:00','dd/mm/yyyy HH24:mi'),1,7,3);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('13/08/2020 15:00','dd/mm/yyyy HH24:mi'),1,6,2);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('14/08/2020 14:00','dd/mm/yyyy HH24:mi'),1,5,1);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('15/08/2020 12:00','dd/mm/yyyy HH24:mi'),2,1,10);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('16/08/2020 10:00','dd/mm/yyyy HH24:mi'),2,2,9);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('17/08/2020 16:00','dd/mm/yyyy HH24:mi'),2,3,8);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('18/08/2020 11:00','dd/mm/yyyy HH24:mi'),2,4,7);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('19/08/2020 10:00','dd/mm/yyyy HH24:mi'),2,5,6);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('20/08/2020 15:00','dd/mm/yyyy HH24:mi'),2,6,5);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('21/08/2020 14:00','dd/mm/yyyy HH24:mi'),2,2,4);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('22/08/2020 12:00','dd/mm/yyyy HH24:mi'),2,7,3);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('23/08/2020 15:00','dd/mm/yyyy HH24:mi'),2,6,2);

INSERT INTO visita(fechavisita, numerovisita, profesional_id_profesional, cliente_id_cliente)
values(TO_DATE('24/08/2020 14:00','dd/mm/yyyy HH24:mi'),2,5,1);

--REPORTECLIENTE
INSERT INTO reportecliente(periodo,indiceaccidentabilidad,morosidad,cliente_id_cliente,profesional_id_profesional)
values (TO_DATE('02/05/2020','dd/mm/yyyy'),'1','0','1','1');

INSERT INTO reportecliente(periodo,indiceaccidentabilidad,morosidad,cliente_id_cliente,profesional_id_profesional)
values (TO_DATE('03/06/2020','dd/mm/yyyy'),'0','0','2','3');

INSERT INTO reportecliente(periodo,indiceaccidentabilidad,morosidad,cliente_id_cliente,profesional_id_profesional)
values (TO_DATE('05/04/2020','dd/mm/yyyy'),'2','0','3','2');

INSERT INTO reportecliente(periodo,indiceaccidentabilidad,morosidad,cliente_id_cliente,profesional_id_profesional)
values (TO_DATE('05/07/2020','dd/mm/yyyy'),'0','1','4','4');

INSERT INTO reportecliente(periodo,indiceaccidentabilidad,morosidad,cliente_id_cliente,profesional_id_profesional)
values (TO_DATE('02/07/2020','dd/mm/yyyy'),'2','0','5','6');

INSERT INTO reportecliente(periodo,indiceaccidentabilidad,morosidad,cliente_id_cliente,profesional_id_profesional)
values (TO_DATE('05/05/2020','dd/mm/yyyy'),'0','1','6','5');

INSERT INTO reportecliente(periodo,indiceaccidentabilidad,morosidad,cliente_id_cliente,profesional_id_profesional)
values (TO_DATE('01/06/2020','dd/mm/yyyy'),'1','0','7','7');

INSERT INTO reportecliente(periodo,indiceaccidentabilidad,morosidad,cliente_id_cliente,profesional_id_profesional)
values (TO_DATE('05/06/2020','dd/mm/yyyy'),'0','0','8','4');

INSERT INTO reportecliente(periodo,indiceaccidentabilidad,morosidad,cliente_id_cliente,profesional_id_profesional)
values (TO_DATE('03/05/2020','dd/mm/yyyy'),'2','0','9','5');

INSERT INTO reportecliente(periodo,indiceaccidentabilidad,morosidad,cliente_id_cliente,profesional_id_profesional)
values (TO_DATE('05/07/2020','dd/mm/yyyy'),'0','1','10','1');

--REPORTEGLOBAL
INSERT INTO reporteglobal(periodo,cantidadcapacitacion,cantidadasesorias,cantidadactividades,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/07/2020','dd/mm/yyyy'),'1','1','2','1','1');

INSERT INTO reporteglobal(periodo,cantidadcapacitacion,cantidadasesorias,cantidadactividades,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/07/2020','dd/mm/yyyy'),'0','2','1','3','2');

INSERT INTO reporteglobal(periodo,cantidadcapacitacion,cantidadasesorias,cantidadactividades,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/06/2020','dd/mm/yyyy'),'2','1','1','2','3');

INSERT INTO reporteglobal(periodo,cantidadcapacitacion,cantidadasesorias,cantidadactividades,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/06/2020','dd/mm/yyyy'),'1','1','1','4','4');

INSERT INTO reporteglobal(periodo,cantidadcapacitacion,cantidadasesorias,cantidadactividades,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/07/2020','dd/mm/yyyy'),'2','2','3','6','5');

INSERT INTO reporteglobal(periodo,cantidadcapacitacion,cantidadasesorias,cantidadactividades,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('03/07/2020','dd/mm/yyyy'),'1','2','2','5','6');

INSERT INTO reporteglobal(periodo,cantidadcapacitacion,cantidadasesorias,cantidadactividades,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('05/05/2020','dd/mm/yyyy'),'3','3','3','7','7');

INSERT INTO reporteglobal(periodo,cantidadcapacitacion,cantidadasesorias,cantidadactividades,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('01/05/2020','dd/mm/yyyy'),'1','1','0','4','8');

INSERT INTO reporteglobal(periodo,cantidadcapacitacion,cantidadasesorias,cantidadactividades,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/07/2020','dd/mm/yyyy'),'1','1','3','5','9');

INSERT INTO reporteglobal(periodo,cantidadcapacitacion,cantidadasesorias,cantidadactividades,profesional_id_profesional,cliente_id_cliente)
values (TO_DATE('02/07/2020','dd/mm/yyyy'),'3','1','3','1','10');

--CHECKLIST
INSERT INTO checklist(version, visita_id_visita)
values (1,1);

INSERT INTO checklist(version, visita_id_visita)
values (1,2);

INSERT INTO checklist(version, visita_id_visita)
values (1,3);

INSERT INTO checklist(version, visita_id_visita)
values (1,4);

INSERT INTO checklist(version, visita_id_visita)
values (1,5);

INSERT INTO checklist(version, visita_id_visita)
values (1,6);

INSERT INTO checklist(version, visita_id_visita)
values (1,7);

INSERT INTO checklist(version, visita_id_visita)
values (1,8);

INSERT INTO checklist(version, visita_id_visita)
values (1,9);

INSERT INTO checklist(version, visita_id_visita)
values (1,10);

INSERT INTO checklist(version, visita_id_visita)
values (1,21);

INSERT INTO checklist(version, visita_id_visita)
values (1,22);

INSERT INTO checklist(version, visita_id_visita)
values (1,23);

INSERT INTO checklist(version, visita_id_visita)
values (1,24);

INSERT INTO checklist(version, visita_id_visita)
values (1,25);

INSERT INTO checklist(version, visita_id_visita)
values (1,26);

INSERT INTO checklist(version, visita_id_visita)
values (2,27);

INSERT INTO checklist(version, visita_id_visita)
values (1,28);

INSERT INTO checklist(version, visita_id_visita)
values (1,29);

INSERT INTO checklist(version, visita_id_visita)
values (2,30);

INSERT INTO checklist(version, visita_id_visita)
values (1,31);

INSERT INTO checklist(version, visita_id_visita)
values (1,41);

INSERT INTO checklist(version, visita_id_visita)
values (1,42);

INSERT INTO checklist(version, visita_id_visita)
values (2,43);

INSERT INTO checklist(version, visita_id_visita)
values (1,44);

INSERT INTO checklist(version, visita_id_visita)
values (1,45);

INSERT INTO checklist(version, visita_id_visita)
values (1,46);

INSERT INTO checklist(version, visita_id_visita)
values (2,47);

INSERT INTO checklist(version, visita_id_visita)
values (1,48);

INSERT INTO checklist(version, visita_id_visita)
values (1,49);

INSERT INTO checklist(version, visita_id_visita)
values (2,50);

INSERT INTO checklist(version, visita_id_visita)
values (2,61);

INSERT INTO checklist(version, visita_id_visita)
values (1,62);

INSERT INTO checklist(version, visita_id_visita)
values (2,63);

INSERT INTO checklist(version, visita_id_visita)
values (1,64);

INSERT INTO checklist(version, visita_id_visita)
values (2,65);

INSERT INTO checklist(version, visita_id_visita)
values (1,66);

INSERT INTO checklist(version, visita_id_visita)
values (2,67);

INSERT INTO checklist(version, visita_id_visita)
values (1,68);

INSERT INTO checklist(version, visita_id_visita)
values (2,69);

INSERT INTO checklist(version, visita_id_visita)
values (2,70);

INSERT INTO checklist(version, visita_id_visita)
values (1,81);

INSERT INTO checklist(version, visita_id_visita)
values (2,82);

INSERT INTO checklist(version, visita_id_visita)
values (2,83);

INSERT INTO checklist(version, visita_id_visita)
values (1,84);

INSERT INTO checklist(version, visita_id_visita)
values (2,85);

INSERT INTO checklist(version, visita_id_visita)
values (1,86);

INSERT INTO checklist(version, visita_id_visita)
values (2,87);

INSERT INTO checklist(version, visita_id_visita)
values (1,88);

INSERT INTO checklist(version, visita_id_visita)
values (2,89);

INSERT INTO checklist(version, visita_id_visita)
values (2,90);

INSERT INTO checklist(version, visita_id_visita)
values (2,101);

INSERT INTO checklist(version, visita_id_visita)
values (2,102);

INSERT INTO checklist(version, visita_id_visita)
values (2,103);

INSERT INTO checklist(version, visita_id_visita)
values (1,104);

INSERT INTO checklist(version, visita_id_visita)
values (2,105);

INSERT INTO checklist(version, visita_id_visita)
values (1,106);

INSERT INTO checklist(version, visita_id_visita)
values (2,107);

INSERT INTO checklist(version, visita_id_visita)
values (1,108);

INSERT INTO checklist(version, visita_id_visita)
values (2,109);

INSERT INTO checklist(version, visita_id_visita)
values (2,110);

INSERT INTO checklist(version, visita_id_visita)
values (2,121);

INSERT INTO checklist(version, visita_id_visita)
values (2,122);

INSERT INTO checklist(version, visita_id_visita)
values (2,123);

INSERT INTO checklist(version, visita_id_visita)
values (2,124);

INSERT INTO checklist(version, visita_id_visita)
values (2,125);

INSERT INTO checklist(version, visita_id_visita)
values (2,126);

INSERT INTO checklist(version, visita_id_visita)
values (2,127);

INSERT INTO checklist(version, visita_id_visita)
values (1,128);

INSERT INTO checklist(version, visita_id_visita)
values (1,129);

INSERT INTO checklist(version, visita_id_visita)
values (2,130);

INSERT INTO checklist(version, visita_id_visita)
values (2,141);

INSERT INTO checklist(version, visita_id_visita)
values (1,142);

INSERT INTO checklist(version, visita_id_visita)
values (2,143);

INSERT INTO checklist(version, visita_id_visita)
values (1,144);

INSERT INTO checklist(version, visita_id_visita)
values (2,145);

INSERT INTO checklist(version, visita_id_visita)
values (2,146);

INSERT INTO checklist(version, visita_id_visita)
values (2,147);

INSERT INTO checklist(version, visita_id_visita)
values (2,148);

INSERT INTO checklist(version, visita_id_visita)
values (2,149);

INSERT INTO checklist(version, visita_id_visita)
values (2,150);

--DETALLE CHECKLIST

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de zapatos de seguridad','No incorporado',1);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de casco de seguridad','Cumplido',1);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de lentes de seguridad','Parcial',1);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Revision nuevas instalaciones','Resuelto',2);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Mejoras en se�alizaciones de seguridad','Resuelto',2);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Se�alizacion de espacios peligrosos','No incorporado',2);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Entrega de ropa de seguridad a trabajadores','Resuelto',2);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Se�alizacion salidas de emergencia','No incorporado',3);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Instalaciones electricas en mal estado','No incorporado',3);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Equipos ergonomicos en mobiliario','Resuelto',3);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Entrega de equipo de seguridad a trabajadores','No incorporado',3);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Instalacion sistema de alarmas','No incorporado',4);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Control de accesos a personal autorizado','No incorporado',4);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Mantencion de areas identificadas y ordenadas','Resuelto',4);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de zapatos de seguridad','No incorporado',5);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de casco de seguridad','Cumplido',5);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de lentes de seguridad','Parcial',5);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Revision nuevas instalaciones','Resuelto',6);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Mejoras en se�alizaciones de seguridad','Resuelto',6);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Se�alizacion de espacios peligrosos','No incorporado',6);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Entrega de ropa de seguridad a trabajadores','Resuelto',6);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Se�alizacion salidas de emergencia','No incorporado',7);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Instalaciones electricas en mal estado','No incorporado',7);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Equipos ergonomicos en mobiliario','Resuelto',7);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Entrega de equipo de seguridad a trabajadores','No incorporado',7);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Instalacion sistema de alarmas','No incorporado',8);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Control de accesos a personal autorizado','No incorporado',8);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Mantencion de areas identificadas y ordenadas','Resuelto',8);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de zapatos de seguridad','No incorporado',9);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de casco de seguridad','Cumplido',9);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de lentes de seguridad','Parcial',9);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Revision nuevas instalaciones','Resuelto',10);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Mejoras en se�alizaciones de seguridad','Resuelto',10);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Se�alizacion de espacios peligrosos','No incorporado',10);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Entrega de ropa de seguridad a trabajadores','Resuelto',21);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Se�alizacion salidas de emergencia','No incorporado',21);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Instalaciones electricas en mal estado','No incorporado',21);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Equipos ergonomicos en mobiliario','Resuelto',21);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Entrega de equipo de seguridad a trabajadores','No incorporado',21);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Instalacion sistema de alarmas','No incorporado',22);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Control de accesos a personal autorizado','No incorporado',22);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Mantencion de areas identificadas y ordenadas','Resuelto',22);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de zapatos de seguridad','No incorporado',23);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de casco de seguridad','Cumplido',23);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de lentes de seguridad','Parcial',23);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Revision nuevas instalaciones','Resuelto',24);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Mejoras en se�alizaciones de seguridad','Resuelto',24);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Se�alizacion de espacios peligrosos','No incorporado',24);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Entrega de ropa de seguridad a trabajadores','Resuelto',25);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Se�alizacion salidas de emergencia','No incorporado',25);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Instalaciones electricas en mal estado','No incorporado',25);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Equipos ergonomicos en mobiliario','Resuelto',26);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Entrega de equipo de seguridad a trabajadores','No incorporado',26);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Instalacion sistema de alarmas','No incorporado',26);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Control de accesos a personal autorizado','No incorporado',27);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Mantencion de areas identificadas y ordenadas','Resuelto',27);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de zapatos de seguridad','No incorporado',27);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de casco de seguridad','Cumplido',28);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de lentes de seguridad','Parcial',28);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Revision nuevas instalaciones','Resuelto',28);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Mejoras en se�alizaciones de seguridad','Resuelto',29);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Se�alizacion de espacios peligrosos','No incorporado',29);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Entrega de ropa de seguridad a trabajadores','Resuelto',30);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Se�alizacion salidas de emergencia','No incorporado',30);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Instalaciones electricas en mal estado','No incorporado',30);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Equipos ergonomicos en mobiliario','Resuelto',41);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Entrega de equipo de seguridad a trabajadores','No incorporado',41);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Instalacion sistema de alarmas','No incorporado',41);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Control de accesos a personal autorizado','No incorporado',41);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Mantencion de areas identificadas y ordenadas','Resuelto',41);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de zapatos de seguridad','No incorporado',42);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de casco de seguridad','Cumplido',42);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de lentes de seguridad','Parcial',42);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Revision nuevas instalaciones','Resuelto',43);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Mejoras en se�alizaciones de seguridad','Resuelto',43);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Se�alizacion de espacios peligrosos','No incorporado',43);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Entrega de ropa de seguridad a trabajadores','Resuelto',44);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Se�alizacion salidas de emergencia','No incorporado',44);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Instalaciones electricas en mal estado','No incorporado',44);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Equipos ergonomicos en mobiliario','Resuelto',45);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Entrega de equipo de seguridad a trabajadores','No incorporado',46);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Instalacion sistema de alarmas','No incorporado',47);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Control de accesos a personal autorizado','No incorporado',47);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Mantencion de areas identificadas y ordenadas','Resuelto',47);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de zapatos de seguridad','No incorporado',48);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de casco de seguridad','Cumplido',48);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Uso de lentes de seguridad','Parcial',48);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Revision nuevas instalaciones','Resuelto',49);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Mejoras en se�alizaciones de seguridad','Resuelto',49);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Se�alizacion de espacios peligrosos','No incorporado',49);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Entrega de ropa de seguridad a trabajadores','Resuelto',49);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Se�alizacion salidas de emergencia','No incorporado',50);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Instalaciones electricas en mal estado','No incorporado',50);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Equipos ergonomicos en mobiliario','Resuelto',50);

INSERT INTO detallechecklist(descripcion, estado, checklist_id_checklist)
values ('Entrega de equipo de seguridad a trabajadores','No incorporado',50);