package cl.awake.psegurito;

public class ReporteGlobalController {

}
