package cl.awake.psegurito.model;

import org.springframework.data.repository.CrudRepository;

public interface VisitaRepository extends CrudRepository<Visita, Integer>{

}
