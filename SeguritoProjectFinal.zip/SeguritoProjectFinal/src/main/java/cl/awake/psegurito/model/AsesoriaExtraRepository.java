package cl.awake.psegurito.model;

import org.springframework.data.repository.CrudRepository;

public interface AsesoriaExtraRepository extends CrudRepository<AsesoriaExtra, Integer> {

}
